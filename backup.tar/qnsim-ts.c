/******************************************************************************
*  Module:   qnsim-ts.c                                                       *
*                                                                             *
*  Author:   Rob Jones                                                        *
*                                                                             *
*  Purpose:  CSci 726 Discrete-Event Simulation: PROJECT #3                   *
*            Provides main simulation program for a general-purpose           *
*            TRANSIENT-STATE SIMULATION of a queuing network consisting       *
*            of single server nodes.                                          *
*                                                                             *
*  Version:  5-02-97                                                          *
*******************************************************************************/

#include "qnet.h"
#include "queue.h"
#include "misc.h"

/* SIMULATION PARAMETERS: */

#define MAX_REPLICATIONS    1000            /* max number of replications     */
#define MAX_EVENTS          100000          /* maximum events per replication */
#define LOC                 0.95            /* level of confidence            */
#define PREC                1.0e-2          /* for rounding data to 1/1000    */
#define INFINITY            1e300           /* a large number                 */

double *future_events;   /* future-events list */

void ProcessArrival(long i, double time)
/******************************************************************************
  Auxilary function used to service the arrival of a job to node 'i' at the
  current 'time' if the node is idle, otherwise the job is put into the queue. 
  If the job is serviced, the job's departure is also scheduled.
*******************************************************************************/
{
  extern rv_func    *random_time;  /* sample function  */
  extern actvty     *status;       /* server status    */
  extern queue_type *queue;        /* service queue    */
  double job_time   = 0;           /* job service time */

  if (status[i] == IDLE) { /* if idle then service job */
    status[i] = BUSY;
    SelectStream(i);
    future_events[i] = time + random_time[i].func();
  } else { /* otherwise, add job to queue */

#ifdef SJF_QUEUE /* if SJF then sample/store service time */
    SelectStream(i);
    job_time = random_time[i].func(); 
#endif

    Insert(&queue[i],job_time);
  }
}

void ServiceJob(long i, double time)
/******************************************************************************
  Auxilary function used to service the next job in the queue of node 'i' at 
  the current 'time' thereby scheduling the departure of the job.                  
*******************************************************************************/
{
  extern rv_func    *random_time;  /* sample function  */
  extern actvty     *status;       /* server status    */
  extern queue_type *queue;        /* service queue    */
  double job_time   = 0;           /* job service time */

  Remove(&queue[i],&job_time);

#ifdef SJF_QUEUE /* if SJF then service time is already stored */

  future_events[i] = time + job_time;

#else /* otherwise sample service-time function */

  SelectStream(i);
  future_events[i] = time + random_time[i].func();

#endif
  status[i] = BUSY;
}

int main(void)
/******************************************************************************
  MAIN PROGRAM
/******************************************************************************
*******************************************************************************/
{
  extern qnt        type;           /* either OPEN or CLOSED                  */
  extern int        num_nodes;      /* number of service nodes                */
  extern rv_func    *random_time;   /* service time random variate functions  */
  extern queue_type *queue;         /* queue for each service node            */
  extern actvty     *status;        /* status of each server: {IDLE,BUSY}     */
  int    node;                      /* service node index                     */
  double clock;                     /* current simulation time                */
  long   i, j;                      /* general-purpose indices                */
  long   index;                     /* replication index                      */
  long   current, next;             /* service node indices                   */
  long   seed = 123456789;          /* random number seed                     */
  long   n;                         /* number of samples                      */
  double u = 1.0 - 0.5*(1.0 - LOC); /* interval parameter                     */ 
  double s, t, diff;                /* used to compute interval estimate      */             
  long   num_arrivals       = 0;    /* counts # of external job arrivals      */
  long   num_departures     = 0;    /* counts # of external job departures    */
  long   num_jobs;                  /* total number of jobs in system         */
  double arrival_rate;              /* average external arrival rate          */
  double departure_rate;            /* average external departure rate        */
  double mean_arrivals      = 0.0;  /* mean # of arrivals until steady state  */
  double sumsqr_arrivals    = 0.0;  /* sum of squares to compute variance     */
  double w;                         /* confidence interval half width         */                
  
  /* initialize */

  Network();  /* get specification of queuing network  */
  Init();     /* initialize of network data structures */ 

  /* create future-event list */
  future_events = (double *)calloc(num_nodes,sizeof(double)); 
  if (future_events == NULL) {
    error(MEM_ERR);
  }

  /* begin simulation */

  for (index = 1; index <= MAX_REPLICATIONS; index++) {

    /* re-initialize the state and statistics for each replication */ 

    /* pick a different seed for each replication */
    SelectStream(0); GetSeed(&seed); PlantSeeds(seed);

    Initialize();          /* reset the initial state of network */

    clock           = 0.0;   
    num_arrivals    = 0;
    num_departures  = 0;
    arrival_rate    = 0.0; /* to get started, make arrival rate */
    departure_rate  = 1.0; /*   different from departure_rate   */

    /* schedule first events */
    if (type == OPEN) {
      SelectStream(0);
      future_events[0] = random_time[0].func();
    } else {
      future_events[0] = INFINITY;
    }
    num_jobs = 0;
    for (i = 1; i < num_nodes; i++) {
      if (IsEmpty(&queue[i]) == FALSE) {
        num_jobs += Number(&queue[i]);
        ServiceJob(i,clock);
      } else {
        status[i]        = IDLE;
        future_events[i] = INFINITY;
      }
    }
    /* 
    *  To estimate the number of external arrivals before the network
    *  reaches steady state, the stopping criteria "flow in = flow out" 
    *  will be used.  To do the comparison, the average arrival rate 
    *  and average departure rate are both rounded to 1/100 precision.  
    */
    while ((arrival_rate != departure_rate) && (num_arrivals < MAX_EVENTS)) {

      /* get next (most imminent) event */
      current = 0; 
      for (j = 0; j < num_nodes; j++) {
        if (future_events[j] < future_events[current]) {
          current = j;
        }
      }
      clock = future_events[current]; /* advance the clock */

      /* if event was an outside arrival then schedule a new one */
      if (current == 0) {
        SelectStream(0);
        future_events[current] = clock + random_time[current].func();
        num_arrivals++; 
        num_jobs++;     /* one more job in system */
      } else { /* process the departure */    
        if (IsEmpty(&queue[current]) == FALSE) { 
          ServiceJob(current,clock); /* service next job in queue */
        } else {
          status[current] = IDLE;
          future_events[current] = INFINITY;
        }
      }
      /* place job in a destination service node */

      next = GetNextNode(current); 

      if (next == 0) { /* if departure from system then */
        num_departures++;
        num_jobs--;           /* one less job in system */
      } else { 
        ProcessArrival(next,clock);
      }          

      /* compute/round arrival/departure rates */
      arrival_rate   = (double)num_arrivals/clock;
      arrival_rate   = (double)(((long)(arrival_rate/PREC + 0.5))*PREC);
      departure_rate = (double)num_departures/clock;
      departure_rate = (double)(((long)(departure_rate/PREC + 0.5))*PREC);

/*======================================================*/
#ifdef DEBUG
      printf("%ld \t %ld \t %f \t %f \t",
             num_arrivals,num_departures,arrival_rate,departure_rate);
      printf("[%ld:%ld:%ld:%ld:%ld]",
             Number(&queue[1]),
             Number(&queue[2]),
             Number(&queue[3]),
             Number(&queue[4]),
             Number(&queue[5]));
      printf("\t %ld",index);
      printf("\t %f",mean_arrivals);
      printf("\n");
#endif
/*======================================================*/

    } /*end while*/ 

    if (num_arrivals == MAX_EVENTS) {
      error("Maximum number of events was reached!\n");
      exit(1);
    }

    /* compute mean number of external arrivals until steady state */
    diff = num_arrivals - mean_arrivals;
    sumsqr_arrivals += diff*diff*(index - 1.0)/index;
    mean_arrivals   += diff/index;

  }/* end for */
    
  /* print results */

  n = index-1;                    /* the number of samples */
  t = idfStudent(n - 1,u);        /* critical value of t   */
  s = sqrt(sumsqr_arrivals/n);    /* standard deviation    */
  w = t*s/sqrt(n - 1);            /* interval half width   */

#ifndef DEBUG

  printf("\nTransient Simulation:\n\n");
  printf("Expected time to steady state:  %.4f +/- %.4f\n\n", 
          mean_arrivals,w);
#endif 
  return(0);
}

