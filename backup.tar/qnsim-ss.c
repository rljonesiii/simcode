/******************************************************************************
*  Module:   qnsim-ss.c                                                       *
*                                                                             *
*  Author:   Rob Jones                                                        *
*                                                                             *
*  Purpose:  CSci 726 Discrete-Event Simulation: PROJECT #3                   *
*            Provides main simulation program for a general-purpose           *
*            STEADY-STATE SIMULATION of a queuing network consisting          *
*            of single server nodes.                                          *
*                                                                             *
*  Version:  5-02-97                                                          *
*                                                                             *
*  Note:     Even though this simulator is capable of simulating an           *
*            open or closed queuing network, the statistics are currently     *
*            applicable for an open network and are referrenced to node 0.    *
*            Also, the within-batch sample index (count) is counting the      *
*            number of departures from network.  If a closed network is       *
*            simulated without using a reference other than node 0, the       *
*            simulation will not terminate.                                   *
*                                                                             *
*******************************************************************************/

#include "qnet.h"
#include "queue.h"
#include "misc.h"

/* SIMULATION PARAMETERS: */

#define MAX_BATCHES      1000           /* maximum number of batches      */
#define BATCH_SIZE       1000           /* batch size (must be > 1)       */
#define INTERVAL_WIDTH   0.05           /* interval half width in percent */
#define LOC              0.95           /* level of confidence            */
#define INFINITY         1e300          /* a large number                 */

double *future_events;   /* future-events list */

void ProcessArrival(long i, double time)
/******************************************************************************
  Auxilary function used to service the arrival of a job to node 'i' at the
  current 'time' if the node is idle, otherwise the job is put into the queue.
  If the job is serviced, the job's departure is also scheduled.
*******************************************************************************/
{
  extern rv_func    *random_time;  /* sample function  */
  extern actvty     *status;       /* server status    */
  extern queue_type *queue;        /* service queue    */
  double job_time   = 0;           /* job service time */

  if (status[i] == IDLE) { /* if idle then service job */
    status[i] = BUSY;
    SelectStream(i);
    future_events[i] = time + random_time[i].func();
  } else { /* otherwise, add job to queue */

#ifdef SJF_QUEUE /* if SJF then sample/store service time */
    SelectStream(i);
    job_time = random_time[i].func(); 
#endif

    Insert(&queue[i],job_time);
  }
}

void ServiceJob(long i, double time)
/******************************************************************************
  Auxilary function used to service the next job in the queue of node 'i' at
  the current 'time' thereby scheduling the departure of the job.
*******************************************************************************/
{
  extern rv_func    *random_time;  /* sample function  */
  extern actvty     *status;       /* server status    */
  extern queue_type *queue;        /* service queue    */
  double job_time   = 0;           /* job service time */

  Remove(&queue[i],&job_time);

#ifdef SJF_QUEUE /* if SJF then service time is already stored */

  future_events[i] = time + job_time;

#else /* otherwise sample service-time function */

  SelectStream(i);
  future_events[i] = time + random_time[i].func();

#endif
  status[i] = BUSY;
}

int main(void)
/******************************************************************************
  MAIN PROGRAM
*******************************************************************************/
{
  extern qnt        type;           /* either OPEN or CLOSED                  */
  extern int        num_nodes;      /* number of service nodes                */
  extern rv_func    *random_time;   /* service time random variate functions  */
  extern queue_type *queue;         /* queue for each service node            */
  extern actvty     *status;        /* status of each server: {IDLE,BUSY}     */
  int    node;                      /* service node index                     */
  double clock;                     /* current simulation time                */
  double prev_clock;                /* previous sim time                      */
  double init_clock;                /* time at start of batch                 */
  long   i, j;                      /* general-purpose indices                */
  long   batch;                     /* batch index                            */
  long   count;                     /* sample counter within a batch          */
  long   current, next;             /* service node indices                   */
  long   seed = 123456789;          /* random number seed                     */
  long   n;                         /* number of samples                      */
  double u = 1.0 - 0.5*(1.0 - LOC); /* interval parameter                     */ 
  double s, t, diff;                /* used to compute interval estimate      */
  long   num_arrivals       = 0;    /* counts # of external job arrivals      */
  long   num_jobs           = 0;    /* total number of jobs in system         */
  double arrival_rate;              /* average external arrival rate          */
  double area_number;               /* time-averaged number of jobs in system */
  double mean_num_jobs      = 0.0;  /* E[number of jobs in system]            */
  double sumsqr_num_jobs    = 0.0;  /* sum of squares to compute variance     */
  double w;                         /* confidence interval half width         */                
/*=============================*/
  long   jobs;
  long   num    = 0;
  long   events;
  double mean   = 0.0;
  double sumsqr = 0.0;
  double ww;
/*=============================*/
  
  /* initialize */

  Network();   /* get specification of queuing network  */
  Init();      /* initialize of network data structures */ 

  /* create future-event list */
  future_events = (double *)calloc(num_nodes,sizeof(double)); 
  if (future_events == NULL) {
    error(MEM_ERR);
  }

  PlantSeeds(seed);
  Initialize();       /* set the initial state of network */
  clock = 0.0;        

  /* schedule first events */
  if (type == OPEN) {
    SelectStream(0);
    future_events[0] = random_time[0].func(); 
  } else {
    future_events[0] = INFINITY; 
  }
  for (i = 1; i < num_nodes; i++) {         
    if (IsEmpty(&queue[i]) == FALSE) {
      num_jobs += Number(&queue[i]);
      ServiceJob(i,clock);
    } else {
      status[i]        = IDLE;
      future_events[i] = INFINITY;                    
    }
  }

  /* begin simulation */

  for (batch = 1; batch <= MAX_BATCHES; batch++) { 

    /* re-initialize the statistics only */
    init_clock  = clock;
    prev_clock  = clock;
    area_number = 0.0;
    count       = 0;

/*=====================================*/
    jobs   = 0;
    events = 0;
/*=====================================*/

    while (count < BATCH_SIZE) {

      /* get next (most imminent) event */
      current = 0; 
      for (j = 0; j < num_nodes; j++) {
        if (future_events[j] < future_events[current]) {
          current = j;
        }
      }
      clock = future_events[current]; /* advance the clock */

      /* if event was an outside arrival then schedule a new one */
      if (current == 0) {
        SelectStream(0);
        future_events[current] = clock + random_time[current].func();
        area_number += num_jobs*(clock - prev_clock);
        prev_clock   = clock;
        num_arrivals++; 
        num_jobs++;     /* one more job in system */
      } else { /* process the departure */    
        if (IsEmpty(&queue[current]) == FALSE) { 
          ServiceJob(current,clock); /* service next job in queue */
        } else {
          status[current] = IDLE;
          future_events[current] = INFINITY;
        }
      }
      /* place job in a destination service node */

      next = GetNextNode(current); 

      if (next == 0) { /* if departure from system then */
        area_number += num_jobs*(clock - prev_clock);
        prev_clock   = clock;
        count++;
        num_jobs--;           /* one less job in system */
      } else { 
        ProcessArrival(next,clock);
      }          
#ifdef METHOD1
    /* compute mean number of jobs in system */
    diff = num_jobs - mean_num_jobs;
    sumsqr_num_jobs += diff*diff*(batch - 1.0)/batch;
    mean_num_jobs   += diff/batch;
#endif
    } /*end while*/ 

#ifdef METHOD2
    /* compute mean number of jobs in system */
    diff = area_number/(clock-init_clock) - mean_num_jobs;
    sumsqr_num_jobs += diff*diff*(batch - 1.0)/batch;
    mean_num_jobs   += diff/batch;
#endif

    /* to reduce some overhead, check on how we're doing every 10 samples */
    if (batch % 10 == 0) {
      n = batch;                    /* the number of samples */
      t = idfStudent(n - 1,u);      /* critical value of t   */
      s = sqrt(sumsqr_num_jobs/n);  /* standard deviation    */
      w = t*s/sqrt(n - 1);          /* interval half width   */
      if (w/mean_num_jobs <= INTERVAL_WIDTH) {
        break; /* exit for loop when desired interval is achieved */
      }
    }

/*=================================================*/
#ifdef DEBUG
    printf("%ld \t",batch);
    printf("%f \t",area_number/(clock-init_clock));
    printf("%f \n",area_number/count);
#endif
/*=================================================*/

  }/* end for */
    
  /* print results */

#ifndef DEBUG
  /* 
  *  need to compute width if "for loop" was exited 
  *  because the maximum number of batched were reached                
  */
  if (batch > MAX_BATCHES) {  
    n = MAX_BATCHES;              /* the number of samples */
    t = idfStudent(n - 1,u);      /* critical value of t   */
    s = sqrt(sumsqr_num_jobs/n);  /* standard deviation    */
    w = t*s/sqrt(n - 1);
  }

  arrival_rate = num_arrivals/clock;

  printf("\nSteady-State Simulation\n");
  printf("  sample points......:  %ld\n",n);
  printf("  confidence level...:  %g%%\n",LOC*100.0);
  printf("  confidence interval:  +/- %g%%\n",INTERVAL_WIDTH*100.0);
  if (w/mean_num_jobs > INTERVAL_WIDTH) {
    printf("\nMeasures did not reach desired interval width.\n");
  }
  printf("\n");
  printf("Expected number of jobs in the system:  %.4f +/- %.4f\n",
          mean_num_jobs, w);
  printf("Expected wait time of a job..........:  %.4f +/- %.4f\n",
          mean_num_jobs/arrival_rate, w/arrival_rate);

#endif /* endif DEBUG */
  return(0);
}

