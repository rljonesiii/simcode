/******************************************************************************
*                                                                             *
*  File:  example954.c                                                        * 
*                                                                             *
*  Project #3 Example:                                                        *
*  Queuing netork description and stochastic specification                    *
*  for a 5 node network in example 9.5.4 of notes.                            *
*                                                                             *
*******************************************************************************/

#include "qnet.h"
#include "const.h"   /* constant model parameters */

#ifdef JACKSON
double service1()
{
  return(Exponential(1.0/nu1));
}
double service2()
{
  return(Exponential(1.0/nu2));
}
double service3()
{
  return(Exponential(1.0/nu3));
}
double service4()
{
  return(Exponential(1.0/nu4));
}
double service5()
{
  return(Exponential(1.0/nu5));
}
#else
double service1()
{
  return(Erlang(5,0.14));
}
double service2()
{
  return(Erlang(4,0.20));
}
double service3()
{
  return(Erlang(5,0.14));
}
double service4()
{
  return(Erlang(4,0.20));
}
double service5()
{
  return(Erlang(4,0.20));
}
#endif

double Expo()
{
  return(Exponential(1.0/lambda));
}


void Network()
/******************************************************************************
  define the queuing network here
*******************************************************************************/
{
  /* declare 5 service nodes */
  Nodes(5);

  /* specify the network connections */
  Connect(0,1,0.4);
  Connect(0,3,0.6);
  Connect(1,2,0.8);
  Connect(1,3,0.2);
  Connect(2,0,0.2);
  Connect(2,1,0.4);
  Connect(2,5,0.4);
  Connect(3,4,1.0);
  Connect(4,2,0.2);
  Connect(4,5,0.8);
  Connect(5,0,1.0);

  /* specify the external inter-arrival time */
  Arrival(Expo);

  /* specify the service times */
  Service(1,service1);
  Service(2,service2);
  Service(3,service3);
  Service(4,service4);
  Service(5,service5);
}

void InitialState()
/******************************************************************************
  define the initial state of the queuing network here
*******************************************************************************/
{
  /* network is initially empty */
}

