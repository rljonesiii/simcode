/******************************************************************************
*  Module:   queue.c                                                      *
*                                                                             *
*  Author:   Rob Jones                                                        *
*                                                                             *
*  Purpose:  CSci 726 Discrete-Event Simulation: PROJECT #3                   *
*            Provides the queue structure and operations for the simulator.   *
*                                                                             *
*  Version:  5-01-97                                                          *
*******************************************************************************/

#include <stdlib.h>
#include "queue.h"
#include "misc.h"

#ifdef SJF_QUEUE

list *free_nodes = NULL;


list *New()
{
  list *ptr;

  if (free_nodes == NULL) {
    ptr = (list *)malloc(sizeof(list));
    if (ptr == NULL) {
      error(MEM_ERR);
    }
  } else {
    ptr        = free_nodes;
    free_nodes = free_nodes->next;
  }
  ptr->item = (item_type)0;
  ptr->next = NULL;
  return(ptr);
}

void Free(list *ptr)
{
  ptr->next  = free_nodes;
  free_nodes = ptr;
}

void CreateQueue(queue_type *q)
{
  q->contents = NULL;
  q->number   = 0;
}

void DeleteQueue(queue_type *q)
{
  list *ptr, *nxt;

  ptr = First(q); 
  while (ptr != NULL) {
    nxt = Next(ptr);
    Free(ptr);
    ptr = nxt;
  }
  ptr = free_nodes; 
  while (ptr != NULL) {
    nxt = Next(ptr);
    Free(ptr);
    ptr = nxt;
  }
  q->contents = NULL;
  free_nodes  = NULL;
  q->number   = 0;
}

void FlushQueue(queue_type *q)
{
  list *ptr, *nxt;

  ptr = First(q);
  while (ptr != NULL) {
    nxt = Next(ptr);
    Free(ptr);
    ptr = nxt;
  }
  q->contents = NULL;
  q->number   = 0;
}

bool IsEmpty(queue_type *q)
{
  if (q->number == 0) {
    return(TRUE);
  } else {
    return(FALSE);
  }
}

long Number(queue_type *q)
{
  return(q->number);
}

void Insert(queue_type *q, item_type v)
{
  list *ptr, *nxt; 
  list *new_entry = New();

  new_entry->item = v;
  if (q->contents == NULL) { 
    q->contents = new_entry;
  } else if (v <= q->contents->item) { 
    new_entry->next = q->contents;
    q->contents     = new_entry;
  } else {
    for (ptr = q->contents; ptr != NULL; ptr = nxt) {
      nxt = ptr->next;
      if (nxt == NULL) {
        ptr->next = new_entry;
      } else if (v <= nxt->item) {
        new_entry->next = nxt;
        ptr->next       = new_entry;
        break;
      }
    }
  }
  q->number++;
}

void Remove(queue_type *q, item_type *v)
{
  list *ptr = q->contents;

  if (q->contents != NULL) {
    (*v) = q->contents->item;
    q->contents = q->contents->next;
    q->number--;
    Free(ptr);
  }
}

list *First(queue_type *q)
{
  return(q->contents);
}

list *Next(list *l)
{
  return(l->next);
}

#endif
